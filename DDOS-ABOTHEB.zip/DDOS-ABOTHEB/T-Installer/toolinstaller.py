import os
import webbrowser
import colorama
from colorama import Fore , Back , Style
colorama.init(autoreset = True)

yellow='\033[93m'
gren='\033[92m'
cyan='\033[96m'
pink='\033[95m'
red='\033[91m'
b='\033[1m'


def ngrokin():
    os.system("pkg install wget")
    os.system("wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz")
    os.system("tar zxvf ngrok-stable-linux-arm.tgz")
    os.system("chmod +x ngrok")
    os.system("mv ngrok $HOME")

def sneakphishin():
    os.system("git clone https://github.com/noob-hackers/sneakphish.git")
    os.system("mv sneakphish $HOME")

def Zphisherin():
    os.system("git clone https://github.com/htr-tech/zphisher.git")
    os.system("mv zphisher $HOME")

def Camphishin():
    os.system("git clone https://github.com/techchipnet/CamPhish.git")
    os.system("mv CamPhish $HOME")

def Webscripin():
    os.system("git clone https://github.com/K4B1R88/Web-Scraping-HACODE.git")
    os.system("mv Web-Scraping-HACODE $HOME")

def Ddosin():
    os.system("git clone https://github.com/K4B1R88/DDOS-By-H4C0D3.git")
    os.system("mv  $HOME")

def theaderin():
    os.system("git clone https://github.com/remo7777/T-Header.git")
    os.system("mv T-Header $HOME")

def kalimuxin():
    os.system("git clone git clone https://github.com/noob-hackers/kalimux")
    os.system("mv kalimux $HOME")

def killshotin():
    os.system("pkg install ruby")
    os.system("git clone https://github.com/bahaabdelwahed/killshot.git")
    os.system("mv killshot $HOME")
    
def IgFreak():
    os.system("pkg install python")
    os.system("pkg install lolcat")
    os.system("git clone https://github.com/T-Dynamos/IgFreak.git")
    os.system("mv IgFreak $HOME")

def nmpain():
    os.system("git clone https://github.com/nmap/nmap.git")
    os.system("mv nmap $HOME")

def metain():
    os.system("git clone https://github.com/rapid7/metasploit-framework.git")
    os.system("mv metasploit-framework $HOME")

def finduserin():
    os.system("git clone https://github.com/xHak9x/finduser.git")
    os.system("mv finduser $HOME")

def nikroin():
    os.system("git clone https://github.com/sullo/nikto.git")
    os.system("mv nikto $HOME")

def fsocietyin():
    os.system("git clone https://github.com/Manisso/fsociety.git")
    os.system("mv fsociety $HOME")

def instashellin():
    os.system("git clone https://github.com/maxrooted/instashell.git")
    os.system("mv instashell $HOME")

def luciferin():
    os.system("git clone https://github.com/rixon-cochi/Lucifer.git")
    os.system("mv Lucifer $HOME")

def distructXin():
    os.system("git clone https://github.com/T-Dynamos/Distruct-X.git")
    os.system("mv Distruct-X $HOME")

def sherlockin():
    os.system("git clone https://github.com/sherlock-project/sherlock.git")
    os.system("mv sherlock $HOME")

def ghostin():
    os.system("git clone https://github.com/jaykali/ghost.git")
    os.system("mv ghost $HOME")

def brut3k1tin():
    os.system("git clone https://github.com/shivankar-madaan/brut3k1t.git")
    os.system("mv brut3k1t $HOME")

def seekerin():
    os.system("git clone https://github.com/thewhiteh4t/seeker.git")
    os.system("mv seeker $HOME")

def sqlmapin():
    os.system("git clone https://github.com/sqlmapproject/sqlmap.git")
    os.system("mv sqlmap $HOME")

def Maliciousin():
    os.system("git clone https://github.com/Mrdarktutorial/Malicious.git")
    os.system("mv Malicious $HOME")

def toolxin():
    os.system("git clone https://github.com/rajkumardusad/Tool-X.git")
    os.system("mv Tool-X $HOME")

def litbrin():
    os.system("git clone https://github.com/lulz3xploit/LittleBrother.git")
    os.system("mv LittleBrother $HOME")

def routsplin():
    os.system("git clone https://github.com/threat9/routersploit.git")
    os.system("mv routersploit $HOME")

def mrphishin():
    os.system("git clone https://github.com/noob-hackers/mrphish.git")
    os.system("mv mrphish $HOME")

def Katanain():
    os.system("git clone https://github.com/PowerScript/KatanaFramework.git")
    os.system("mv KatanaFramework $HOME")

def redhawkin():
    os.system("git clone https://github.com/Tuhinshubhra/RED_HAWK.git")
    os.system("mv RED_HAWK $HOME")

def trapein():
    os.system("git https://github.com/jofpin/trape.git")
    os.system("mv trape $HOME")








def logo():
    os.system('clear')
    print('''

▀▀█▀▀ █▀▀█ █▀▀█ █░░ 
░▒█░░ █░░█ █░░█ █░░                ./HACODE
░▒█░░ ▀▀▀▀ ▀▀▀▀ ▀▀▀

▀█▀ █▀▀▄ █▀▀ ▀▀█▀▀ █▀▀█ █░░ █░░ █▀▀ █▀▀█ 
▒█░ █░░█ ▀▀█ ░░█░░ █▄▄█ █░░ █░░ █▀▀ █▄▄▀ 
▄█▄ ▀░░▀ ▀▀▀ ░░▀░░ ▀░░▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀░▀▀
''')
    

def first():
	os.system('clear')
	logo()
	print("")
	print(cyan+b+"----------------------------------"+b+cyan)
	print(gren+b+"Author	: HACODE                 |"+b+gren)
	print (red+b+"Team	: UNITED HACKERS         |"+b+red)
	print (yellow+b+"YouTube	: HACODE                 |"+b+yellow)
	print(cyan+b+"----------------------------------"+b+cyan)

def start():
    print(f'''
{gren+b}[{red+b}1{b+red}{b+gren}]---START
{gren+b}[{red+b}2{b+red}{b+gren}]---UPDATE
{gren+b}[{red+b}3{b+red}{b+gren}]---ABOUT
{gren+b}[{red+b}4{b+red}{b+gren}]---MORE
{gren+b}[{red+b}5{b+red}{b+gren}]---FOLLOW
{gren+b}[{red+b}6{b+red}{b+gren}]---VIDEO
{gren+b}[{red+b}7{b+red}{b+gren}]---CHAT NOW
{gren+b}[{red+b}8{b+red}{b+gren}]---RESTART
{gren+b}[{red+b}9{b+red}{b+gren}]---EXIT ''')
    c = " "
    while(c != 9):
        print("")
        c = int(input(f"{cyan+b}./HACODE:{b+cyan}{b+yellow} "))
        if c == 1:
            os.system('clear')
            common()
        elif c == 2:
            
            
            print("")
            print(f"{Fore.YELLOW}This Tool Updating Very Soon")
            print(f"{Fore.YELLOW}keep wait")
            print("")
        elif c == 3:
            
       
            print('''
							
							
░█████╗░██████╗░░█████╗░██╗░░░██╗████████╗
██╔══██╗██╔══██╗██╔══██╗██║░░░██║╚══██╔══╝
███████║██████╦╝██║░░██║██║░░░██║░░░██║░░░
██╔══██║██╔══██╗██║░░██║██║░░░██║░░░██║░░░
██║░░██║██████╦╝╚█████╔╝╚██████╔╝░░░██║░░░
╚═╝░░╚═╝╚═════╝░░╚════╝░░╚═════╝░░░░╚═╝░░░          
                     
THIS TOOLS IS ONLY FOR EDUCATIONAL PURPOSE SO'
IM NOT RESPONSIBLE IF YOU DO ANY ILLEGAL THINGS'
THANKS FOR READING SUBSCRIBE {HACODE}'
HAVE A GOOD DAY BUDDIE :)
''')
        elif c == 4:
            
            print(f"{Fore.YELLOW}Comming More Surprices for you")
        elif c == 5:
            
            webbrowser.open("https://www.instagram.com/hacode_88/")
        elif c == 6:
            os.system('clear')
            logo()
            webbrowser.open("https://youtube.com/channel/UCi00gqBm4n98-dg7ND7gsrg")
        elif c == 7:
            
            webbrowser.open("https://chat.whatsapp.com/JnrKsQW55tFAvq3iTgO2Ut")
        elif c == 8:
            os.system('clear')
            logo()
            start()
            start.first("kriss")
        elif c == 9:
            exit()



def common():
    os.system("clear")
    first()
    print(f'''
{gren+b}[{red+b}1{b+red}{b+gren}]--Ngrok        {gren+b}[{red+b}11{b+red}{b+gren}]--Metasploit   {gren+b}[{red+b}21{b+red}{b+gren}]--Seeker      {gren+b}[{red+b}98{b+red}{b+gren}]--Back
{gren+b}[{red+b}2{b+red}{b+gren}]--Sneakphish   {gren+b}[{red+b}12{b+red}{b+gren}]--FindUser     {gren+b}[{red+b}22{b+red}{b+gren}]--Sqlmap      {gren+b}[{red+b}99{b+red}{b+gren}]--Exit
{gren+b}[{red+b}3{b+red}{b+gren}]--Zphisher     {gren+b}[{red+b}13{b+red}{b+gren}]--Nikto        {gren+b}[{red+b}23{b+red}{b+gren}]--Malicious   
{gren+b}[{red+b}4{b+red}{b+gren}]--Camphish     {gren+b}[{red+b}14{b+red}{b+gren}]--Fsociety     {gren+b}[{red+b}24{b+red}{b+gren}]--Tool-X      
{gren+b}[{red+b}5{b+red}{b+gren}]--Webscrip     {gren+b}[{red+b}15{b+red}{b+gren}]--Instashell   {gren+b}[{red+b}25{b+red}{b+gren}]--LittleBro   
{gren+b}[{red+b}6{b+red}{b+gren}]--DDOS         {gren+b}[{red+b}16{b+red}{b+gren}]--Lucifer      {gren+b}[{red+b}26{b+red}{b+gren}]--Routerspl   
{gren+b}[{red+b}7{b+red}{b+gren}]--Kalimux      {gren+b}[{red+b}17{b+red}{b+gren}]--Distruct-X   {gren+b}[{red+b}27{b+red}{b+gren}]--Mrphish    
{gren+b}[{red+b}8{b+red}{b+gren}]--Killshot     {gren+b}[{red+b}18{b+red}{b+gren}]--Sherlock     {gren+b}[{red+b}28{b+red}{b+gren}]--Katana   
{gren+b}[{red+b}9{b+red}{b+gren}]--IgFreak      {gren+b}[{red+b}19{b+red}{b+gren}]--Ghost        {gren+b}[{red+b}29{b+red}{b+gren}]--Redhawk   
{gren+b}[{red+b}10{b+red}{b+gren}]--NMap        {gren+b}[{red+b}20{b+red}{b+gren}]--brut3k1t     {gren+b}[{red+b}30{b+red}{b+gren}]--Trape   
    ''')
    
    tool = int(input(f"{cyan+b}./HACODE:{b+cyan}{b+yellow} "))
    
    if tool==1:
        ngrokin()
    elif tool==2:
        sneakphishin()
    elif tool==3:
        Zphisherin()
    elif tool==4:
        Camphishin()
    elif tool==5:
        Webscripin()
    elif tool==6:
        Ddosin()
    elif tool==7:
        kalimuxin()
    elif tool==8:
        killshotin()
    elif tool==9:
        IgFreak()
    elif tool==10:
        nmpain()
    elif tool==11:
        metain()
    elif tool==12:
        finduserin()
    elif tool==13:
        nikroin()
    elif tool==14:
        fsocietyin()
    elif tool==15:
        instashellin()
    elif tool==16:
        luciferin()
    elif tool==17:
        distructXin()
    elif tool==18:
        sherlockin()
    elif tool==19:
        ghostin()
    elif tool==20:
        brut3k1tin()
    elif tool==21:
        seekerin()
    elif tool==22:
        sqlmapin()
    elif tool==23:
        Maliciousin()
    elif tool==24:
        toolxin()
    elif tool==25:
        litbrin()
    elif tool==26:
        routsplin()
    elif tool==27:
        mrphishin()
    elif tool==28:
        Katanain()
    elif tool==29:
        redhawkin()
    elif tool==30:
        trapein()
    elif tool==98:
        os.system("clear")
        first()
        start()
    elif tool==99:
        exit()

def handle():
    first()
    start()
    #common()

handle()