CMD
 - git clone https://github.com/Robert1526/Samp-Ddos-Tools
 - cd Samp-Ddos-Tools
 - python3 nann.py
